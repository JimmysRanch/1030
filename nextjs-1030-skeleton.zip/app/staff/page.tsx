export default function Page() {
  return (
    <section>
      <h1>Staff</h1>
      <p>This page runs without a backend.</p>
    </section>
  );
}
